**************
  DirArchive
**************

Overview
--------
Move files to a datetimestamped folder.

Accessing a folder that contains lots of files, such as an archive folder,
can take up lots of time. By splitting up this folder into (datetimestamped) 
subfolders, the access time will increase.


Arguments
---------

DirArchive [-d <path>] [-o <number>] [-p <prefix>] [-s {d|w|m|y}] [-t]
           [-v] [-w {mon|tue|wed|thu|fri|sat|sun}] <file>

Optional parameters:
-d <path>: Destination folder.
  By default the archive folder is a subfolder of the source file. This 
  argument will allow the use of a different destination of the archive 
  folder. Relative direction is allowed and will be relative from the view of
  the current directory.

-o <number>: Move files that are the given number of days old or older. 
  By default the utility will move all files to the archive folder regardless
  of the age of the file. With this option in place, the utility will only 
  look at files older the the given number of days.
  Note: When the number is 0 or not valid, the utility will abort.

-p <prefix>: Put the given text a prefix of the archive folder. 
  Enclose the name between dubble quotes (") to be able to use the space
  character.

-s {d|w|m|y}: Splitting argument.
  By default the files will be moved to the datetimestamped archive folder
  based on a weekly periode. This option will change the splitting argument
  to daily (d), weekly (w), monthly (m) or yearly (y).

-t: Switch to test mode. 
  Putting on this switch will disable the actual moving of the files for 
  testing purposes.

-v: Switch to verbose mode.
  Show the files that have been moved. By default the names are not shown.

-w {mon|tue|wed|thu|fri|sat|sun}: Start of the week.
  By default the utility will take monday as start of the week. This option
  will set the given day as start of the week.

<file> (mandatory)
  File to be moved to the timestamped subdirectory. Pathname and wildcards 
  are allowed.


ErrorLevel
----------
0x00: No errors, files have been found and have been moved.
0x01: Some files could not be moved. The archive folder could not be 
      created or the file already existed.
0x02: No files found to move. The source folder is empty or does not exist.
0x03: Error in processing the argument values.
0x04: Error in parameters.
