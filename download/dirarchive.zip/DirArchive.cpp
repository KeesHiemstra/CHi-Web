/*****************************************************************************************\

	DirArchive.cpp

	Version:
	1.00 (2005-08-28)
	- Possible bufferflow in creating the NewFile string.

	1.00 beta (2005-08-23)
	- Initial version

	Author:
	Kees Hiemstra

	Purpose:
	Move files to a folder with a datestamp.

	Accessing a folder that contains lots of files, such as an archive folder, can take up
	lots of time. By splitting up this folder into subfolders with a datestamp, the
	access time will increase.

	See the readme.txt for the arguments used by this utility.

\*****************************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <io.h>
#include <time.h>
#include <string.h>
#include <direct.h>

/* definitions */
#define	VERSION						"1.00 beta release"
#define	OPTION_NONE				0x00
#define	OPTION_ARCHIVEBIT 0x01
#define	OPTION_TESTONLY		0x02
#define	OPTION_VERBOSE		0x04

/* gobal constants */
const char WeekdayAbbr[7][4] = {"sun", "mon", "tue", "wed", "thu", "fri", "sat"};
const	char *WeekdayFull[7] = {"Sun", "Mon", "Tues", "Wednes", "Thurs", "Fri", "Satur"};

/* global vars */
int		 Option = OPTION_NONE;                 /* Switches */
char	 OptionDestination[_MAX_FNAME] = "\0"; /* Destination folder name */
int		 OptionOlder = 0;                      /* Minimum age of the file before it will be moved */
char	 *OptionPrefix = NULL;                 /* Make this part of the datestamped folder name */
char	 OptionSplitting = 'w';                /* Split files at Days, Weeks, Months or Years */
char	 OptionWeekStart = 1;                  /* The week starts at given day (default = Monday) */
char	 FileName[_MAX_FNAME] = "\0";          /* File name passed from command line */
char	 FilePath[_MAX_PATH];									 /* Path part of file name */
time_t MoveBefore;

/* prototypes */
void DisplayUsage( void );
void DisplayParams( void );
int ParseArguments( int argc, char *argv[] );
int PreProcess( void );
int Process( void );
int ProcessFile( _finddata_t *pFile );

int main( int argc, char *argv[] )
{
	int	Error = 0; /* Error returned from Process() */

	if ( ParseArguments( argc, argv ) == 1 ) {
		printf( "DirArchine version %s\n\n", VERSION );
		DisplayUsage();
		return 4;
	};

	if (  Option & (OPTION_TESTONLY | OPTION_VERBOSE) )
		printf( "DirArchive version %s\n", VERSION );

	if ( PreProcess() ) {
		printf( "DirArchive can not process the given values at the parameters\n" );
		return 3;
	};

	if ( Option & OPTION_TESTONLY ) {
		DisplayParams();
	};

	if ( (Error = Process()) != 0 ) {
		if ( Error < 0 )
			return 2; /* No files to move */
		printf( "DirArchive failed to move %i file%s\n", Error, (Error == 1) ? "" : "s" );
		return 1;
	};

	return 0;
};

/******************************************************************************************
 * DisplayUsage
 *
 * Purpose:
 * Display information summary of this utility.
 *
 */
void DisplayUsage( void )
{
	printf( "Usage: DirArchive [-d <path>] [-o <number>] [-p <prefix>] [-s {d|w|m|y}] [-t]\n" );
	printf( "                  [-v] [-w {mon|tue|wed|thu|fri|sat|sun}] <file>\n\n" );
	printf( "Optional parameters:\n" );
	printf( " -d <path>: Destination folder.\n" );
	printf( " -o <number>: Move files that are the given number of days old or older.\n" );
	printf( " -p <prefix>: Put the given text a prefix of the archive folder.\n" );
	printf( " -s {d|w|m|y}: Splitting argument. Create a folder for every different\n" );
	printf( "               day (d), week (w), month (m) or year (y).\n" );
	printf( " -t: Switch to test mode.\n" );
	printf( " -v: Switch to verbose mode.\n" );
	printf( " -w {mon|tue|wed|thu|fri|sat|sun}: Start of the week.\n\n" );
	printf( "The <file> argument is mandatory. Wildcards are allowed.\n\n" );
};

/******************************************************************************************
 * DisplayParams
 *
 * Pupose:
 * Display parameters on the screen.
 *
 * Parameters:
 *  None.
 *
 * Return value:
 *	None.
 *
 */
void DisplayParams ( void )
{
	/* show parameter results */
	printf ( "Parameter list:\n" );
	printf ( "Set archive bit      : %s\n", (Option & OPTION_ARCHIVEBIT) ? "On" : "Off" );
	printf ( "Use destination path : %s...\n", OptionDestination );
	printf ( "Move files older than: %i days%s\n", OptionOlder, (OptionOlder == 0) ? " (all files)" : "" );
	printf ( "Splitting files on   : %c\n", OptionSplitting );
	printf ( "Test mode            : %s\n", (Option & OPTION_TESTONLY) ? "On" : "Off" );
	printf ( "Verbose              : %s\n", (Option & OPTION_VERBOSE) ? "On" : "Off" );
	printf ( "The week starts with : %sday\n", WeekdayFull[OptionWeekStart] );
	printf ( "File(s) to move      : %s\n", FileName );
}

/******************************************************************************************
 * ParseAguments
 *
 * Purpose:
 * Parse the arguments from the command line.
 *
 * Parameters:
 *  the number of arguments.
 *  the argument list.
 *
 * Return value:
 *	0 = No error.
 *  1 = Error.
 *
 */
int ParseArguments( int argc, char *argv[] )
{
	char drive[_MAX_DRIVE];
	char dir[_MAX_DIR];
	char fname[_MAX_FNAME];
	char ext[_MAX_EXT];
	int	 i, Error = 0;

	for ( i = 1; i < argc; i++ ) {
		/* switch or option */
		if ( (argv[i][0] == '-') || (argv[i][0] == '/') ) {
			switch ( argv[i][1] ) {
			case 'a':
			case 'A':
				Option |= OPTION_ARCHIVEBIT;
				break;
			case 'd':
			case 'D':
				strcpy( OptionDestination, argv[++i] );
				if ( OptionDestination[strlen(OptionDestination) - 1] != '\\' )
					strcat( OptionDestination, "\\" );
				break;
			case 'o':
			case 'O':
				OptionOlder = atoi( argv[++i] );
				if ( OptionOlder == 0 )
						Error++;
				break;
			case 'p':
			case 'P':
				OptionPrefix = argv[++i];
				break;
			case 's':
			case 'S':
				OptionSplitting = argv[++i][0];
				break;
			case 't':
			case 'T':
				Option |= OPTION_TESTONLY;
				break;
			case 'v':
			case 'V':
				Option |= OPTION_VERBOSE;
				break;
			case 'w':
			case 'W':
				i++;
				OptionWeekStart = 0;
				while ( (_stricmp( argv[i], WeekdayAbbr[OptionWeekStart] )) && (OptionWeekStart < 7) )
					OptionWeekStart++;
				if ( OptionWeekStart == 7 )
					Error++;
				break;
			default:
				printf ( "Illegal option: %s\n", argv[i] );
				Error++;
				break;
			};
		} else {
			strcpy( FileName, argv[i] );
		};
	};
	
	/* File name missing or errors encountered in options */
	if( (Error > 0) || (FileName[0] == 0) )
		return 1;

	/* Extract source path from filename */
	_splitpath( FileName, drive, dir, fname, ext );
	strcpy( FilePath, drive );
	strcat( FilePath, dir );
	
	/* Use the source path if no destination path is given */
	if ( OptionDestination[0] == 0 )
		strcpy( OptionDestination, FilePath );

	/* Add the prefix if a prefix is given */
	if ( OptionPrefix != NULL ) 
		strcat( OptionDestination, OptionPrefix);

	return 0;
};

/******************************************************************************************
 * PrePropress
 *
 * Purpose:
 * Prepare the data for processing.
 *  - Calculate MoveBefore
 *
 * Parameters:
 *  None.
 *
 * Return value:
 *	0 = No error.
 *  1 = Error.
 *
 */
int PreProcess( void )
{
	time_t				CurrentTime;
	struct tm			*tmMoveBefore;

	/* Calculate the time at midnight */
	time( &CurrentTime );
	tmMoveBefore = localtime( &CurrentTime );
	tmMoveBefore->tm_hour = 0;
	tmMoveBefore->tm_min = 0;
	tmMoveBefore->tm_sec = 0;

	/* Calculate the time for the -o option                               */
	/* All files newer than today minus OptionOlder days are not touchted */
	/* example: Today August 23 with the -o of 7 days will move the of    */
	/*          August 16 23:59:59 but not August 17 00:00:00             */
	MoveBefore = mktime( tmMoveBefore ) - ((OptionOlder - 1) * 60 * 60 * 24);

	return 0;
};

/******************************************************************************************
 * Process
 *
 * Purpose:
 * Loop through the files given from the filemask at command prompt.
 *
 * Parameters:
 *  None.
 *
 * Return value:
 *  -1 = No files found.
 *	 0 = No error.
 *  >0 = Number of files that could not be moved.
 *
 */
int Process( void )
{
	long					hDir = NULL;		/* Handle to the folder */
	int						iFileFound;			/* File found result */
	_finddata_t		rFile;					/* File data */
	int						Error = 0;			/* Counting the number of file that can not be moved */

	/* Find the first file that matches the file mask */
	if ( (iFileFound = hDir = _findfirst( FileName, &rFile )) < 0 ) {
		printf( "DirArchive could not find any matches with %s\n", FileName );
		return -1;
	};

	/* Loop through the files in the directory */
	while ( iFileFound >= 0 ) {
		/* don't process directories */
		if ( ((rFile.attrib & _A_SUBDIR) == 0) && (rFile.time_write < MoveBefore) )
			if ( ProcessFile( &rFile ) != 0 )
				Error++;
		iFileFound = _findnext( hDir, &rFile );
	};

	_findclose( hDir );

	return Error;
};

/******************************************************************************************
 * ProcessFile
 *
 * Purpose:
 *  Move the given to the new location. 
 *
 * Parameters:
 *  None.
 *
 * Return value:
 *	0 = No error.
 *  1 = Error.
 *
 */
int ProcessFile( _finddata_t *pFile )
{
	time_t				CalcTime;
	struct tm			*tmCalcTime;
	char					OldName[_MAX_FNAME];
	char					NewName[_MAX_FNAME];

	/* Create soure filename */
	strcpy( OldName, FilePath );
	strcat( OldName, pFile->name );

	/* Create destination filename */
	strcpy( NewName, OptionDestination );

	/* Calculate the beginning of the week, month or year */
	switch ( OptionSplitting ) {
	case 'y':
		tmCalcTime = localtime( &pFile->time_write );
		tmCalcTime->tm_mday = 1;
		tmCalcTime->tm_mon = 0;
		break;
	case 'm':
		tmCalcTime = localtime( &pFile->time_write );
		tmCalcTime->tm_mday = 1;
		break;
	case 'w':
		tmCalcTime = localtime( &pFile->time_write );
		CalcTime = pFile->time_write - (((tmCalcTime->tm_wday - OptionWeekStart + 7) % 7) * 60 * 60 * 24);
		tmCalcTime = localtime( &CalcTime );
		break;
	case 'd':
		tmCalcTime = localtime( &pFile->time_write );
		break;
	};

	/* Add the date to destination path */
	if ( strftime( &NewName[strlen( NewName )], (_MAX_FNAME - strlen( NewName )), "%Y-%m-%d", tmCalcTime ) == 0 ) {
		printf( "Error creating new name...\n" );
		return 1;
	};

	/* Create new directory */
	if ( (Option & OPTION_TESTONLY) == 0 )
		_mkdir( NewName );

	/* Complete the destination filename */
	strcat( NewName, "\\");
	strcat( NewName, pFile->name );

	/* Move the file */
	if ( (Option & OPTION_TESTONLY) == 0 )
		if ( rename( OldName, NewName ) != 0 )
			return 1;

	if ( (Option & (OPTION_TESTONLY | OPTION_VERBOSE)) )
		printf( "%s ==> %s\n", OldName, NewName );
	
	return 0;
};

